/** Every texture key in the game. Add new art here first. */
export const Tex = {
  Varu: 'varu',
  VaruLegL: 'varu_leg_l',
  VaruLegR: 'varu_leg_r',
  VaruBelt: 'varu_belt',
  VaruBeltGold: 'varu_belt_gold',
  VaruDrag1: 'varu_drag_1',
  VaruDrag2: 'varu_drag_2',
  VaruEmo: 'varu_emo',
  VaruEmoDrag1: 'varu_emo_drag_1',
  CatNormal: 'cat_normal',
  CatFat: 'cat_fat',
  CatNinja: 'cat_ninja',
  CatKamikaze: 'cat_kamikaze',
  CatFlying: 'cat_flying',
  CatFlyingBody: 'cat_flying_body',
  CatWingL: 'cat_wing_l',
  CatWingR: 'cat_wing_r',
  CatLucky: 'cat_lucky',
  CatBomber: 'cat_bomber',
  CatTennis: 'cat_tennis',
  CatBomberArm: 'cat_bomber_arm',
  CatTennisArm: 'cat_tennis_arm',
  CatTennisRacket: 'cat_tennis_racket',
  BossQueen: 'boss_queen',
  BossQueenCape: 'boss_queen_cape',
  BossQueenCrown: 'boss_queen_crown',
  BossQueenScepter: 'boss_queen_scepter',
  BossQueenFootL: 'boss_queen_foot_l',
  BossQueenFootR: 'boss_queen_foot_r',
  BossQueenBack: 'boss_queen_back',
  BossQueenSide: 'boss_queen_side',
  BossMafia: 'boss_mafia',
  BossMafiaBack: 'boss_mafia_back',
  BossMafiaSide: 'boss_mafia_side',
  BossFederer: 'boss_federer',
  BossFedererArm: 'boss_federer_arm',
  BossFedererRacket: 'boss_federer_racket',
  BossFedererTail: 'boss_federer_tail',
  BossFedererFootL: 'boss_federer_foot_l',
  BossFedererFootR: 'boss_federer_foot_r',
  BossFedererFront: 'boss_federer_front',
  BossFedererSide: 'boss_federer_side',
  Yarn: 'yarn',
  Tennis: 'tennis',
  BallMachine: 'ball_machine',
  Fireball: 'fireball',
  Smoke: 'smoke',
  Heart: 'heart',
  MilkDrop: 'milk_drop',
  MilkPuddle: 'milk_puddle',
  BeltThrown: 'belt_thrown',
  BeltThrownGold: 'belt_thrown_gold',
  PickupCrochete: 'pickup_crochete',
  PickupCigarettes: 'pickup_cigarettes', // the second look of the crochete pickup
  PickupVape: 'pickup_vape', // the third look of the crochete pickup
  PickupLapte: 'pickup_lapte',
  PickupMilkBottle: 'pickup_milk_bottle', // the second look of the lapte pickup
  PickupMonster: 'pickup_monster',
  PickupRedBull: 'pickup_redbull', // the second look of the Monster pickup
  PickupGoldenBelt: 'pickup_golden_belt',
  PickupLaser: 'pickup_laser',
  PickupUmbrella: 'pickup_umbrella',
  UmbrellaCanopy: 'umbrella_canopy', // the open umbrella seen from above, held over Varu while the buff runs
  DodgeIcon: 'dodge_icon', // Varu rolling over, on the dodge badge
  PickupScooter: 'pickup_scooter',
  ScooterBody: 'scooter_body', // the scooter seen from above, under Varu while the buff runs
  PickupIceCream: 'pickup_ice_cream',
  IceBlock: 'ice_block', // the ice block drawn over a cat frozen by the ice cream
  PickupMystery: 'pickup_mystery',
  PickupRoulette: 'pickup_roulette', // the second look of the question mark
  PickupSnail: 'pickup_snail',
  PickupDumbbell: 'pickup_dumbbell',
  PickupEmo: 'pickup_emo',
  PickupRusty: 'pickup_rusty',
  PickupBig: 'pickup_big',
  PickupSmoke: 'pickup_smoke',
  Petard: 'petard',
  LampStem: 'lamp_stem',
  LampHead: 'lamp_head',
  LampBase: 'lamp_base',
  PickupCrow: 'pickup_crow',
  CrowDazed: 'crow_dazed',
  Crow: 'crow',
  CrowFlap: 'crow_flap',
  CrowFold: 'crow_fold',
  CrowGold: 'crow_gold',
  CrowGoldFlap: 'crow_gold_flap',
  CrowGoldFold: 'crow_gold_fold',
  CrowKamikaze: 'crow_kamikaze',
  CrowKamikazeFlap: 'crow_kamikaze_flap',
  CrowKamikazeFold: 'crow_kamikaze_fold',
  Feather: 'feather',
  BarrelWhole: 'barrel_whole',
  BarrelBroken: 'barrel_broken',
  BarrelPuddle: 'barrel_puddle',
  FxPuddle: 'fx_puddle', // v174 cartoon effects (art/fx.ts)
  FxFlood: 'fx_flood', // v180 the big flat puddle of the emo scream
  FxBubbleQueen: 'fx_bubble_queen',
  FxBubbleEmo: 'fx_bubble_emo',
  FxRing: 'fx_ring',
  FxCarpetTile: 'fx_carpet_tile',
  FxDiamond: 'fx_diamond',
  FxShock: 'fx_shock',
  FxDisc: 'fx_disc', // v200 flat disc + thin ring: tinted atlas images instead of `add.circle` shapes
  FxHoop: 'fx_hoop',
  FxBar: 'fx_bar', // v202 a solid white block, stretched + tinted into the edges / fills of ground warnings (see FX_BAR_PX)
  FxCarpetPad: 'fx_carpet_pad',
  FxPuff: 'fx_puff',
  FlagPole: 'flag_pole', // v201 the surrender flag as two pictures (art/flag.ts)
  FlagCloth: 'flag_cloth',
  FxDrop: 'fx_drop',
  Star: 'star',
  Leaf: 'leaf',
  Chip: 'chip',
  Shadow: 'shadow',
  Particle: 'particle',
  Grass: 'grass',
  Tileset: 'arena_tiles',
  CampusText: 'campus_text',
  PhotoPlaceholder: 'photo_placeholder',
} as const;

export type TexKey = (typeof Tex)[keyof typeof Tex];

/**
 * Friend photo slots. The three boss ids are the same as the boss types, so a boss intro card
 * finds its photo by the boss name. `gameOver` and `ending` are the two end screens.
 */
export const PHOTO_IDS = ['queen', 'mafia', 'federer', 'gameOver', 'ending'] as const;
export type PhotoId = (typeof PHOTO_IDS)[number];

/** Phaser cache key of a real photo loaded from the photo manifest. */
export const photoKey = (id: PhotoId): string => `photo:${id}`;
