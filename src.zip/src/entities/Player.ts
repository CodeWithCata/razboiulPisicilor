/** @file Varu: movement, aim, damage, belt visuals, walk / smoke-break / energy back flip animation, power-up multipliers. */
import { texArgs, texRef } from '../assets/atlas';
import Phaser from 'phaser';
import { Tex, type TexKey } from '../assets/keys';
import { PLAYER } from '../config/balance';
import { SCOOTER } from '../config/scooter';
import { DODGE } from '../config/dodge';
import { sampleKeys } from '../core/ease';
import { bus, Events, type DodgeRollPayload, type IdleHabitPayload, type PlayerHealthPayload, type PlayerHurtPayload } from '../core/events';
import type { InputSource } from '../input/InputSource';
import { Actor } from './Actor';
import { MilkTrail } from './MilkTrail';
import { PlayerDrops } from './PlayerDrops';
import { gameClock } from '../core/clock';
import { CIG_SMOKE, ENERGY_FLIP, ENERGY_TRAIL, type FlipLook, EMO_FX, GOLD_BELT, IDLE_HABITS, MILK_FX, MILK_TRAIL, RUST_FX, SMOKE_BREAK, VARU_ANIM, type ZLook } from '../config/animation';
import { setCircleHitbox } from '../core/sprite';
import { BELT_FX, css, FONT } from '../config/style';
import { getDifficulty } from '../core/difficulty';
import { hyp } from '../core/hyp';

/** Body frames of the cigarette drag: arm down, half way, cigarette at his mouth. */
const BODY_FRAMES: readonly TexKey[] = [Tex.Varu, Tex.VaruDrag1, Tex.VaruDrag2];
/** The emo bad buff: hood up, then pushed back as the arm rises, and down while the cigarette is at his mouth (he is the normal Varu then). */
const EMO_BODY_FRAMES: readonly TexKey[] = [Tex.VaruEmo, Tex.VaruEmoDrag1, Tex.VaruDrag2];

const smoothstep = (u: number): number => u * u * (3 - 2 * u);

/** Varu. Sprite must face UP; we rotate it toward the aim direction. */
export class Player extends Actor {
  /** Power-ups will change these later (milk, energy drink, golden belt). */
  speedMultiplier = 1;
  /** Slowed by the floor (a mustard puddle): 1 = normal. BarrelSystem sets it every frame before Varu moves; it never mixes with the power-up speed above. */
  terrainSlow = 1;
  /** Slowed by the emo cat's tear puddles (`TearPuddles`, 1 = normal). Separate from `terrainSlow`, which the mustard puddles set every frame. */
  tearSlow = 1;
  damageMultiplier = 1;
  /** Share of `damageMultiplier` that comes from the permanent belt upgrades (the streak only looks "buffed" for the timed buffs above it). */
  upgradeDamage = 1;
  /** Permanent belt upgrade: every belt hit shoves cats this much harder. */
  knockbackMultiplier = 1;
  rangeMultiplier = 1;
  /** Bad buffs (PowerUpSystem sets them): the pause between plain swings and the spin / throw cooldowns get this many times longer, and the body grows (1 = normal). */
  swingCooldownMultiplier = 1;
  specialCooldownMultiplier = 1;
  sizeMultiplier = 1;
  /** True while the emo buff is active (PowerUpSystem sets it): hood up, broken hearts over his head. */
  emo = false;
  /** True while the golden belt is active (PowerUpSystem sets it): gold strap, sticky white goo. */
  goldenBelt = false;
  /** True while the umbrella buff is active (PowerUpSystem sets it): balls, shots and petards bounce off (ProjectileSystem, GameScene), the canopy is drawn by UmbrellaSystem. */
  umbrella = false;
  /** True while the scooter buff is active (PowerUpSystem sets it): ScooterSystem draws the scooter under him and bumps the cats that touch him; GameScene lets those cats' bites through. */
  scooter = false;
  /** True while the milk buff is active (PowerUpSystem sets it): drippy white trail. */
  milkTrail = false;
  /** True while the energy drink buff is active (PowerUpSystem sets it): small green Z z z letters behind him. */
  energyTrail = false;
  /** True while the rusty belt buff is active (PowerUpSystem sets it): rust flakes come off the belt. */
  rustyFlakes = false;
  private rustTimer = 0;

  /** Current aim direction (normalized). Ninja cats use it to appear behind Varu. */
  readonly facing = new Phaser.Math.Vector2(0, -1);

  private invincibleUntil = 0;
  /** Dev only (debug key G): nothing hurts Varu. */
  godMode = false;
  private phase = 0;
  private rockAmount = 0;
  private legSwing = 0;
  private readonly legL: Phaser.GameObjects.Image;
  private readonly legR: Phaser.GameObjects.Image;
  private readonly heldBelt: Phaser.GameObjects.Image;
  private readonly smoke: Phaser.GameObjects.Particles.ParticleEmitter;
  private smokeTimer = 0;
  /** Cigarette drag: ms since it started (-1 = not smoking), how far the arm is up (0..1), which body frame shows. */
  private breakMs = -1;
  private breakPose = 0;
  private bodyFrame = 0;
  private exhaled = false;
  /** Idle habits (config IDLE_HABITS): how long he has stood still, when the next habit is due, the one running, the last one, and the lean they add. */
  private idleMs = 0;
  private nextHabitAt: number = IDLE_HABITS.afterMs;
  private habit: { kind: 'belt' | 'neck'; ms: number } | null = null;
  private lastHabit: 'drag' | 'belt' | 'neck' | null = null;
  private habitTilt = 0;
  private beltTilt = 0;
  private readonly ember: Phaser.GameObjects.Image;
  /** Goo dripping off the golden belt in his fist, and the splat when he grabs it. */
  private readonly goo: Phaser.GameObjects.Particles.ParticleEmitter;
  private readonly gooBurst: Phaser.GameObjects.Particles.ParticleEmitter;
  private gooTimer = 0;
  /** The milk trail: a smeared white ribbon on the ground (drawn from his recent path) plus splotches beside it. */
  private readonly milkLine: MilkTrail;
  /** The Z z z trail: where the last letter dropped, how many have dropped (picks the size), idle timer. */
  private zLast: { x: number; y: number } | null = null;
  private zCount = 0;
  private zTimer = 0;
  private emoTimer = 0;
  private bodyEmo = false;
  /** Big Varu: the scale he was built with, and how big he is right now (eases toward `sizeMultiplier`). */
  private baseScale = 1;
  private sizeNow = 1;
  /** The smoke break: he cannot walk or start a swing until this game time (gameClock). */
  private frozenUntil = 0;
  /**
   * The energy drink back flip (config ENERGY_FLIP): ms since it started (-1 = not flipping). While it runs the real body is hidden and
   * `flipBody` plays the somersault in its place (with the legs and belt), so the body's scale and hitbox never change.
   */
  private flipMs = -1;
  /** The numbers the running somersault uses: the energy drink's back flip or the dodge roll. */
  private flipLook: FlipLook = ENERGY_FLIP;
  /** True while the somersault is a dodge roll (he moves along `rollDir` and cannot be hit). */
  private flipIsRoll = false;
  /** The roll phase of the dodge started (the launch dust and whoosh fired). */
  private rollLaunched = false;
  /** How fast he was walking when the roll phase starts (px/s): the roll begins at this speed so he never stops first. */
  private rollStartSpeed = 0;
  /** His walking momentum during the roll phase (px/s): starts at the walk speed and follows the stick, so the roll never brakes him. */
  private rollCarry = 0;
  /** The post-roll speed boost runs until this game time (gameClock). */
  private boostUntil = -Infinity;
  /** The way the scooter points (radians, like `rotation`) while he rides; ScooterSystem draws the scooter along it. */
  scooterHeading = 0;
  private wasOnScooter = false;
  private readonly rollDir = new Phaser.Math.Vector2(0, -1);
  private lastSaveAt = -Infinity;
  /** Where the stand-in parts are: position, turn, and the scale across (`sx`) and along (`sy`, negative = flipped over) his body. */
  private readonly flipPose = { on: false, x: 0, y: 0, rot: 0, sx: 1, sy: 1 };
  private flipGhostMs = 0;
  /** The landing was already announced for this flip. */
  private flipLanded = false;
  private readonly flipBody: Phaser.GameObjects.Image;
  private beltIsGold = false;
  private readonly tipPoint = new Phaser.Math.Vector2();
  /** One scratch point for the event effects (exhale, golden flourish, rust flakes): each use fills it and reads it at once, so they can share it. */
  private readonly scratchPoint = new Phaser.Math.Vector2();
  /** Rust flakes and broken hearts (two emitters). */
  private readonly drops: PlayerDrops;
  /** False while the belt swings or flies: the belt in his fist is hidden then (BeltSystem sets it). */
  beltInHand = true;
  /** Extra turn (radians) while the belt spins him around (BeltSystem sets it). */
  spinTurn = 0;
  /** True during the golden tornado spin: the body and legs are hidden inside it (BeltSystem sets it). */
  hiddenInTornado = false;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    super(scene, x, y, Tex.Varu, { maxHp: PLAYER.maxHp, size: PLAYER.size, hitRadius: PLAYER.hitRadius });
    this.legL = scene.add.image(x, y, ...texArgs(Tex.VaruLegL)).setDepth(19);
    this.legR = scene.add.image(x, y, ...texArgs(Tex.VaruLegR)).setDepth(19);
    this.heldBelt = scene.add.image(x, y, ...texArgs(Tex.VaruBelt)).setDepth(21);
    this.flipBody = scene.add.image(x, y, ...texArgs(Tex.Varu)).setDepth(20).setVisible(false);
    this.smoke = scene.add.particles(0, 0, texRef(Tex.Particle).key, { frame: texRef(Tex.Particle).frame,
      emitting: false,
      lifespan: CIG_SMOKE.lifespanMs,
      speed: CIG_SMOKE.speed,
      angle: CIG_SMOKE.angleDeg,
      scale: CIG_SMOKE.scale,
      alpha: CIG_SMOKE.alpha,
      tint: [...CIG_SMOKE.tint],
    }).setDepth(22);
    this.drops = new PlayerDrops(scene);
    this.ember = scene.add.image(x, y, ...texArgs(Tex.Particle)).setTint(SMOKE_BREAK.ember.tint).setDepth(23).setVisible(false);
    this.goo = scene.add.particles(0, 0, texRef(Tex.MilkDrop).key, { frame: texRef(Tex.MilkDrop).frame,
      emitting: false,
      gravityY: MILK_FX.gravity * GOLD_BELT.drops.gravityMult,
      lifespan: GOLD_BELT.held.lifespanMs,
      speed: GOLD_BELT.held.speed,
      scale: GOLD_BELT.held.scale,
      alpha: GOLD_BELT.held.alpha,
      tint: [...GOLD_BELT.goo],
    }).setDepth(22);
    this.gooBurst = scene.add.particles(0, 0, texRef(Tex.MilkDrop).key, { frame: texRef(Tex.MilkDrop).frame,
      emitting: false,
      gravityY: MILK_FX.gravity * GOLD_BELT.drops.gravityMult,
      lifespan: GOLD_BELT.flourish.lifespanMs,
      speed: GOLD_BELT.flourish.speed,
      scale: GOLD_BELT.flourish.scale,
      alpha: GOLD_BELT.flourish.alpha,
      tint: [...GOLD_BELT.goo],
    }).setDepth(22);
    this.milkLine = new MilkTrail(scene, 3);
    this.setCollideWorldBounds(true);
    this.setDepth(20);
    this.baseScale = this.scaleX;
    this.emitHealth();
  }

  tick(input: InputSource): void {
    if (!this.alive) return;

    if (this.rollActive) {
      const t = this.flipMs;
      const walk = PLAYER.speed * this.speedMultiplier * this.terrainSlow * this.tearSlow;
      const target = this.rollDir.angle() + Math.PI / 2;
      if (t < DODGE.windupMs) {
        // Wind-up: he does NOT stop. He keeps walking as before, crouches, and swings round toward the roll (the way can still change).
        if (input.move.x !== 0 || input.move.y !== 0) this.rollDir.set(input.move.x, input.move.y).normalize();
        this.rollStartSpeed = input.move.x !== 0 || input.move.y !== 0 ? walk : 0;
        this.rollCarry = this.rollStartSpeed;
        if (!this.isKnockedBack) this.setVelocity(input.move.x * walk, input.move.y * walk);
        this.facing.copy(input.aim);
        this.setRotation(this.rotation + Phaser.Math.Angle.Wrap(target - this.rotation) * 0.4);
      } else {
        const heldNow = input.move.x !== 0 || input.move.y !== 0;
        const rollEnd = DODGE.windupMs + DODGE.rollMs;
        if (t < rollEnd) {
          // Roll: a burst along the roll direction (swells and eases to 0) ON TOP of his walking momentum. The momentum (`rollCarry`) starts at
          // the walk speed and follows the stick, so he never brakes to a stop: if he keeps a direction held he comes out of the roll walking.
          // The burst (`peak`) is worked out so the whole roll still covers `distancePx` (carry gives start speed times the time, the sine 2/pi of the peak times it).
          const into = Phaser.Math.Clamp((t - DODGE.windupMs) / DODGE.rollMs, 0, 1);
          const seconds = DODGE.rollMs / 1000;
          const dt = Math.min(gameClock.scaled(this.scene.game.loop.delta), 50) / 1000;
          this.rollCarry += ((heldNow ? walk : 0) - this.rollCarry) * (1 - Math.exp(-dt * DODGE.carryFollow));
          const peak = Math.max(0, DODGE.distancePx / seconds - this.rollStartSpeed) * (Math.PI / 2);
          const burst = peak * Math.sin(Math.PI * into);
          this.setVelocity(this.rollDir.x * burst + input.move.x * this.rollCarry, this.rollDir.y * burst + input.move.y * this.rollCarry);
          this.facing.copy(this.rollDir);
          this.setRotation(target);
        } else {
          // Recover: he uncurls but is back in control right away (full steering at the boosted speed), so the roll flows into the run.
          const speed = walk * (1 + (DODGE.boost.mult - 1) * Phaser.Math.Clamp((t - rollEnd) / DODGE.recoverMs, 0, 1)); // eases up to the boost the roll hands over to
          if (!this.isKnockedBack) this.setVelocity(input.move.x * speed, input.move.y * speed);
          this.facing.copy(input.aim);
          const aimRot = input.aim.angle() + Math.PI / 2;
          this.setRotation(this.rotation + Phaser.Math.Angle.Wrap(aimRot - this.rotation) * 0.35);
        }
      }
      this.waddle();
      this.syncShadow();
      return;
    }
    if (!this.isKnockedBack) {
      // Only when `ENERGY_FLIP.rooted` is on: planted during the back flip. By default he keeps full control while he flips.
      const planted = ENERGY_FLIP.rooted && this.flipMs >= 0;
      const speed = planted || this.frozen ? 0 : PLAYER.speed * this.speedMultiplier * this.terrainSlow * this.tearSlow * this.rollBoost();
      this.setVelocity(input.move.x * speed, input.move.y * speed);
    }
    this.facing.copy(input.aim);
    this.setRotation(this.restingRotation(input.aim.angle() + Math.PI / 2) + this.spinTurn);
    this.waddle();
    this.rotation += this.habitTilt; // neck crack
    this.syncShadow();
  }

  /**
   * The turn his body has. Normally he looks at the aim. On the scooter he stands on the deck: his feet and hips follow the way the scooter
   * rolls (`scooterHeading`, which turns smoothly toward where he moves) and only his upper body twists toward the aim, at most `SCOOTER.ride.twistRad`.
   */
  private restingRotation(aimRotation: number): number {
    if (!this.scooter) {
      this.wasOnScooter = false;
      return aimRotation;
    }
    const R = SCOOTER.ride;
    if (!this.wasOnScooter) {
      this.wasOnScooter = true;
      this.scooterHeading = aimRotation; // hops on facing the way he looks, then the scooter takes over
    }
    const body = this.body as Phaser.Physics.Arcade.Body;
    if (body.speed > R.minSpeed) {
      const heading = Math.atan2(body.velocity.y, body.velocity.x) + Math.PI / 2;
      this.scooterHeading = Phaser.Math.Angle.RotateTo(this.scooterHeading, heading, R.turnRate);
    }
    const twist = Phaser.Math.Clamp(Phaser.Math.Angle.Wrap(aimRotation - this.scooterHeading), -R.twistRad, R.twistRad);
    return this.scooterHeading + twist;
  }

  /** The speed factor of the boost after a dodge roll: `DODGE.boost.mult` for the first part, then easing back to 1. */
  private rollBoost(): number {
    const B = DODGE.boost;
    const left = (this.boostUntil - gameClock.now) / B.ms; // 1 right after the roll, 0 when it is over
    if (left <= 0) return 1;
    const fade = Math.min(1, left / (1 - B.holdShare));
    return 1 + (B.mult - 1) * Phaser.Math.Easing.Sine.Out(fade);
  }

  /** Smooth waddle: rock left and right while walking, eased in and out. */
  private waddle(): void {
    if (this.scooter) {
      // Standing on the deck: both feet planted, no walking rock.
      this.legSwing = 0;
      this.rockAmount = 0;
      return;
    }
    if (!VARU_ANIM.enabled) return;
    const dt = Math.min(gameClock.scaled(this.scene.game.loop.delta), 50) / 1000; // game time: slow-mo slows the waddle too
    const speed = (this.body as Phaser.Physics.Arcade.Body).speed;
    const moving = speed >= VARU_ANIM.idleSpeed;
    if (moving) this.phase += speed * dt * VARU_ANIM.radPerPx;
    const target = moving ? 1 : 0;
    this.rockAmount += (target - this.rockAmount) * Math.min(1, VARU_ANIM.blendPerSec * dt);
    this.legSwing = Math.sin(this.phase) * this.rockAmount * VARU_ANIM.legSwing;
    if (this.rockAmount < 0.01) return;
    this.rotation += Math.sin(this.phase) * this.rockAmount * Phaser.Math.DegToRad(VARU_ANIM.tiltDeg);
  }

  /** Standing still for a while: now and then he does a small thing (drag, check the belt, crack his neck). Any move, swing, spin or hit ends it. */
  private updateIdleHabits(delta: number): void {
    const H = IDLE_HABITS;
    const body = this.body as Phaser.Physics.Arcade.Body | null;
    const still =
      H.enabled && this.alive && body !== null && body.speed < VARU_ANIM.idleSpeed && !this.isKnockedBack && this.beltInHand && this.spinTurn === 0 && !this.hiddenInTornado;
    if (!still) {
      this.idleMs = 0;
      this.nextHabitAt = H.afterMs;
      this.habit = null;
      this.habitTilt = 0;
      this.beltTilt = 0;
      return;
    }
    this.idleMs += delta;
    const habit = this.habit;
    if (habit) {
      habit.ms += delta;
      const look = H[habit.kind];
      const u = habit.ms / look.ms;
      if (u >= 1) {
        this.habit = null;
        this.habitTilt = 0;
        this.beltTilt = 0;
        return;
      }
      const tilt = Phaser.Math.DegToRad(sampleKeys(u, look.times, look.tiltDeg));
      if (habit.kind === 'neck') this.habitTilt = tilt;
      else this.beltTilt = tilt;
      return;
    }
    if (this.idleMs >= this.nextHabitAt && this.breakMs < 0 && this.flipMs < 0) this.startHabit();
  }

  /** Picks the next habit (never the same twice in a row, by weight) and sets when the one after it is due. */
  private startHabit(): void {
    const H = IDLE_HABITS;
    this.nextHabitAt = this.idleMs + Phaser.Math.Between(H.gapMs.min, H.gapMs.max);
    const kinds = (Object.keys(H.weights) as Array<'drag' | 'belt' | 'neck'>).filter((k) => k !== this.lastHabit);
    let roll = Math.random() * kinds.reduce((sum, k) => sum + H.weights[k], 0);
    let kind = kinds[0]!;
    for (const k of kinds) {
      roll -= H.weights[k];
      if (roll <= 0) {
        kind = k;
        break;
      }
    }
    this.lastHabit = kind;
    if (kind === 'drag') {
      this.smokeBreak(); // the cigarette pose, smoke and line that already exist
      return;
    }
    this.habit = { kind, ms: 0 };
    const at = kind === 'belt' ? this.handPosition() : { x: this.x, y: this.y };
    const payload: IdleHabitPayload = { x: at.x, y: at.y, habit: kind };
    bus.emit(Events.IdleHabit, payload);
  }

  /** A point on the body texture (relative to its center) in world space: follows his turn and size. */
  private bodyPoint(local: { readonly x: number; readonly y: number }, out: Phaser.Math.Vector2): Phaser.Math.Vector2 {
    const k = this.scaleX;
    const lx = local.x * k;
    const ly = local.y * k;
    const c = Math.cos(this.rotation);
    const s = Math.sin(this.rotation);
    return out.set(this.x + lx * c - ly * s, this.y + lx * s + ly * c);
  }

  /** Where his right fist is in the world. The belt swings from here. */
  handPosition(out = new Phaser.Math.Vector2()): Phaser.Math.Vector2 {
    return this.bodyPoint(BELT_FX.handOffset, out);
  }

  /** Where the cigarette tip is now: at his side, or at his mouth while the arm is up. */
  private tipLocal(): { x: number; y: number } {
    const a = CIG_SMOKE.tipOffset;
    const b = SMOKE_BREAK.tipOffset;
    return { x: a.x + (b.x - a.x) * this.breakPose, y: a.y + (b.y - a.y) * this.breakPose };
  }

  /** A little smoke puff from the cigarette now and then (time from the frame delta, so it waits during pause). */
  private puffSmoke(delta: number): void {
    if (!CIG_SMOKE.enabled || !this.alive) return;
    this.smokeTimer += delta;
    if (this.smokeTimer < CIG_SMOKE.everyMs) return;
    this.smokeTimer -= CIG_SMOKE.everyMs;
    const tip = this.bodyPoint(this.tipLocal(), this.tipPoint);
    this.smoke.emitParticleAt(tip.x, tip.y, 1);
  }

  /** Food or energy drink: he takes a drag. The arm swings up, the tip glows, then a cloud of smoke goes out in front of him. Visual only. */
  smokeBreak(quiet = false): void {
    if (!SMOKE_BREAK.enabled || !this.alive) return;
    this.breakMs = 0;
    this.exhaled = false;
    bus.emit(Events.SmokeBreak, { x: this.x, y: this.y, quiet });
  }

  /** True while he is stuck in a smoke break (BeltSystem starts no new attack then). */
  get frozen(): boolean {
    return gameClock.now < this.frozenUntil;
  }

  /** Dev helper: ends a smoke break freeze at once. */
  thaw(): void {
    this.frozenUntil = 0;
  }

  /** The bad smoke break: he stops (no walking, no new swing) for `ms` and takes a drag. The line comes from the pickup's label, so the drag is quiet. */
  freeze(ms: number): void {
    if (!this.alive) return;
    this.frozenUntil = gameClock.now + ms;
    this.smokeBreak(true);
  }

  /** The energy drink: he plants his feet, crouches, springs up and does one somersault on the spot. Animation only (ENERGY_FLIP); a second can in mid air does nothing. */
  backflip(): void {
    if (!ENERGY_FLIP.enabled || !this.alive || this.flipMs >= 0 || this.hiddenInTornado) return;
    this.flipLook = ENERGY_FLIP;
    this.flipIsRoll = false;
    this.flipMs = 0;
    this.flipGhostMs = 0;
    this.flipLanded = false;
    this.flipBody.setTexture(...texArgs(this.frame.name)); // the pose he has right now
  }

  /** True during the whole dodge move (wind-up, roll, recover): the walk and the belt hand are overridden. */
  get rollActive(): boolean {
    return this.flipMs >= 0 && this.flipIsRoll;
  }

  /** True while the dodge roll protects him (from `DODGE.safeFromMs`, inside the wind-up, to the end): nothing can hit him. */
  get rolling(): boolean {
    return this.rollActive && this.flipMs >= DODGE.safeFromMs;
  }

  /** Can a roll start now? (alive, not in a smoke break, not inside the golden tornado, not mid spin, not already rolling.) */
  get canRoll(): boolean {
    return DODGE.enabled && this.alive && !this.frozen && !this.hiddenInTornado && this.spinTurn === 0 && !this.rollActive;
  }

  /** Starts the dodge roll toward (dx, dy) (any length; zero = the way he faces). The cooldown is DodgeSystem's job. */
  startRoll(dx: number, dy: number): void {
    if (!this.canRoll) return;
    if (dx * dx + dy * dy < 0.0001) this.rollDir.copy(this.facing);
    else this.rollDir.set(dx, dy);
    this.rollDir.normalize();
    this.knockbackUntil = 0;
    this.flipLook = DODGE.anim;
    this.flipIsRoll = true;
    this.flipMs = 0;
    this.flipGhostMs = 0;
    this.flipLanded = true; // no landing show for a roll
    this.rollLaunched = false;
    this.rollStartSpeed = dx * dx + dy * dy < 0.0001 ? 0 : PLAYER.speed * this.speedMultiplier * this.terrainSlow * this.tearSlow;
    this.flipBody.setTexture(...texArgs(this.frame.name));
    const started: DodgeRollPayload = { x: this.x, y: this.y, angle: this.rollDir.angle() };
    bus.emit(Events.DodgeRoll, started);
  }

  /** Moves the flip on one frame and works out where its parts are (`flipPose`). Runs BEFORE the body is shown or hidden, so the last frame is never empty. `delta` is game ms. */
  private advanceBackflip(delta: number): void {
    if (this.flipMs < 0) return;
    const F = this.flipLook;
    if (!this.alive || this.hiddenInTornado) {
      this.endBackflip();
      return;
    }
    this.flipMs += delta;
    const u = this.flipMs / F.ms;
    if (u >= 1) {
      this.endBackflip();
      return;
    }
    // `p` runs 0..1 from takeoff to touchdown; `air` is 0 on the ground and 1 at the top (a parabola, so he hangs at the top).
    const p = Phaser.Math.Clamp((u - F.takeoff) / (F.touchdown - F.takeoff), 0, 1);
    const air = 1 - (2 * p - 1) ** 2;
    const turn = F.turns * Math.PI * 2 * Phaser.Math.Easing.Sine.InOut(p);
    // Squash and stretch: crouch, push-off stretch, none in the air, squash on landing, settle.
    const times = [0, F.takeoff, F.takeoff + F.launch, F.touchdown - F.launch, F.touchdown, 1];
    const squashX = sampleKeys(u, times, [0, F.crouch.x, F.stretch.x, 0, F.landing.x, 0]);
    const squashY = sampleKeys(u, times, [0, F.crouch.y, F.stretch.y, 0, F.landing.y, 0]);
    // The somersault seen from above: his length (the way he faces) shrinks to a sliver, flips over (negative) and grows back.
    let along = Math.cos(turn);
    if (Math.abs(along) < F.minLength) along = along < 0 ? -F.minLength : F.minLength;
    const grow = this.scaleX * (1 + F.hop * air) * (1 - (1 - (F.tuck ?? 1)) * air);
    const pose = this.flipPose;
    pose.on = true;
    pose.x = this.x; // rides along with him wherever he walks (his body and hitbox never leave the floor)
    pose.y = this.y - F.jumpPx * air; // only up the screen
    pose.rot = this.rotation;
    pose.sx = grow * (1 + squashX);
    pose.sy = grow * (1 + squashY) * along;
    this.setShadowJump(1 - (1 - F.shadowSize) * air, 1 - (1 - F.shadowAlpha) * air);
    if (!this.flipLanded && u >= F.touchdown) {
      this.flipLanded = true;
      bus.emit(Events.BackflipLand, { x: this.x, y: this.y });
    }
    if (this.flipIsRoll && !this.rollLaunched && this.flipMs >= DODGE.windupMs) {
      this.rollLaunched = true;
      const launched: DodgeRollPayload = { x: this.x, y: this.y, angle: this.rollDir.angle() };
      bus.emit(Events.DodgeLaunch, launched);
    }
    this.flipGhostMs += delta;
    if (air > 0.05 && this.flipGhostMs >= F.ghost.everyMs) {
      this.flipGhostMs = 0;
      this.dropGhost();
    }
  }

  /** A green copy of the body that stays where it was and fades out: the speed lines of the spin. Tweens are scene-owned, so a restart cleans them up. */
  private dropGhost(): void {
    const G = this.flipLook.ghost;
    const pose = this.flipPose;
    const ghost = this.scene.add
      .image(pose.x, pose.y, ...texArgs(this.flipBody.frame.name))
      .setRotation(pose.rot)
      .setScale(pose.sx, pose.sy)
      .setDepth(G.depth)
      .setAlpha(G.alpha)
      .setTint(G.tint)
      .setTintMode(Phaser.TintModes.FILL);
    this.scene.tweens.add({ targets: ghost, alpha: 0, scaleX: pose.sx * 0.85, scaleY: pose.sy * 0.85, duration: G.lifeMs, ease: 'Sine.easeOut', onComplete: () => ghost.destroy() });
  }

  /** Puts the stand-in body, the legs and the belt on the flip pose (after they were placed the normal way). */
  private applyBackflip(): void {
    const pose = this.flipPose;
    for (const part of [this.flipBody, this.legL, this.legR, this.heldBelt]) part.setPosition(pose.x, pose.y).setScale(pose.sx, pose.sy);
    this.flipBody.setRotation(pose.rot).setAlpha(this.alpha).setVisible(true);
    for (const leg of [this.legL, this.legR]) leg.setRotation(pose.rot).setAlpha(this.alpha).setVisible(true);
    this.heldBelt.setRotation(pose.rot + this.beltTilt).setVisible(this.beltInHand);
  }

  private endBackflip(): void {
    if (this.flipIsRoll) {
      this.invincibleUntil = Math.max(this.invincibleUntil, gameClock.now + DODGE.graceMs);
      this.boostUntil = gameClock.now + DODGE.boost.ms; // the quick speed boost after the roll
    }
    this.flipIsRoll = false;
    this.flipMs = -1;
    this.flipPose.on = false;
    this.flipBody.setVisible(false);
    this.setShadowJump(1, 1);
  }

  /** The golden belt just landed in his fist: it flashes gold and splats goo. */
  goldenBeltFlourish(): void {
    if (!GOLD_BELT.enabled || !this.alive) return;
    const f = GOLD_BELT.flourish;
    const at = this.bodyPoint(f.burstOffset, this.scratchPoint);
    this.gooBurst.explode(f.drops, at.x, at.y);
    this.heldBelt.setTint(f.flashTint).setTintMode(Phaser.TintModes.FILL);
    this.scene.time.delayedCall(f.flashMs, () => {
      if (!this.heldBelt.active) return;
      this.heldBelt.clearTint();
      this.heldBelt.setTintMode(Phaser.TintModes.MULTIPLY);
    });
  }

  /** Runs the cigarette drag: arm up (smooth), hold with a glowing tip, blow the smoke out, arm down. */
  private updateSmokeBreak(delta: number): void {
    const s = SMOKE_BREAK;
    if (this.breakMs >= 0 && !this.alive) {
      this.breakMs = -1;
      this.breakPose = 0;
    }
    if (this.breakMs >= 0) {
      this.breakMs += delta;
      const t = this.breakMs;
      const holdEnd = s.raiseMs + s.holdMs;
      if (t < s.raiseMs) this.breakPose = smoothstep(t / s.raiseMs);
      else if (t < holdEnd) this.breakPose = 1;
      else if (t < holdEnd + s.lowerMs) {
        if (!this.exhaled) {
          this.exhaled = true;
          this.exhale();
        }
        this.breakPose = 1 - smoothstep((t - holdEnd) / s.lowerMs);
      } else {
        this.breakMs = -1;
        this.breakPose = 0;
      }
    }

    const frame = this.breakPose < 0.25 ? 0 : this.breakPose < 0.75 ? 1 : 2;
    if (frame !== this.bodyFrame || this.emo !== this.bodyEmo) {
      this.bodyFrame = frame;
      this.bodyEmo = this.emo;
      this.setTexture(...texArgs((this.emo ? EMO_BODY_FRAMES : BODY_FRAMES)[frame])); // emo: the hood is up, except during the drag
    }

    // The tip glows brighter and pulses while the cigarette is at his mouth.
    const glowing = this.breakMs >= 0 && frame === 2;
    this.ember.setVisible(glowing && this.visible);
    if (glowing) {
      const tip = this.bodyPoint(this.tipLocal(), this.tipPoint);
      const pulse = 0.5 + 0.5 * Math.sin(this.breakMs / s.ember.pulseMs);
      this.ember.setPosition(tip.x, tip.y).setScale(this.scaleX * (s.ember.scale.min + (s.ember.scale.max - s.ember.scale.min) * pulse) * 2);
    }
  }

  /** A stream of smoke puffs out of his mouth, in the direction he faces. Tweened images, no emitter, so they can be aimed. */
  private exhale(): void {
    const e = SMOKE_BREAK.exhale;
    const mouth = this.scratchPoint; // refilled at the start of every puff's callback and read in the same call
    for (let i = 0; i < e.puffs; i++) {
      this.scene.time.delayedCall(i * e.staggerMs, () => {
        if (!this.active) return;
        this.bodyPoint(SMOKE_BREAK.mouthOffset, mouth);
        const angle = this.facing.angle() + Phaser.Math.FloatBetween(-e.spreadRad, e.spreadRad);
        const dist = Phaser.Math.FloatBetween(e.distance.min, e.distance.max);
        const puff = this.scene.add
          .image(mouth.x, mouth.y, ...texArgs(Tex.Particle))
          .setDepth(22)
          .setTint(e.tint[Phaser.Math.Between(0, e.tint.length - 1)])
          .setAlpha(e.alpha.start)
          .setScale(e.scale.start);
        this.scene.tweens.add({
          targets: puff,
          x: mouth.x + Math.cos(angle) * dist,
          y: mouth.y + Math.sin(angle) * dist,
          scale: e.scale.end,
          alpha: e.alpha.end,
          duration: Phaser.Math.Between(e.durationMs.min, e.durationMs.max),
          ease: 'Cubic.easeOut',
          onComplete: () => puff.destroy(),
        });
      });
    }
  }

  /** He just drank the milk: a big white splat of splotches around him. */
  milkSplash(): void {
    if (!MILK_TRAIL.enabled || !this.alive) return;
    this.milkLine.splash(this.x, this.y, gameClock.now);
  }

  /** While the milk buff lasts he smears a white ribbon behind him (MilkTrail does the drawing and keeps the buffers). */
  private updateMilkTrail(delta: number): void {
    if (!MILK_TRAIL.enabled) return;
    this.milkLine.update(delta, gameClock.now, this.milkTrail && this.alive, this.x, this.y, this.rotation);
  }

  /** While the energy drink lasts he leaves little green "Z z z" letters behind him. They float up, sway and fade. */
  private updateEnergyTrail(delta: number): void {
    const cfg = ENERGY_TRAIL;
    if (!cfg.enabled) return;
    if (!this.energyTrail || !this.alive) {
      this.zLast = null;
      return;
    }
    const last = this.zLast;
    if (!last) {
      this.zLast = { x: this.x, y: this.y };
      return;
    }
    if (hyp(this.x - last.x, this.y - last.y) >= cfg.everyPx) {
      last.x = this.x;
      last.y = this.y;
      this.zTimer = 0;
      this.dropZ();
      return;
    }
    // Standing still: he keeps snoring.
    this.zTimer += delta;
    if (this.zTimer >= cfg.idleEveryMs) {
      this.zTimer = 0;
      this.dropZ();
    }
  }

  /** While the emo buff lasts (hood up, see `updateSmokeBreak`), little broken hearts drift up over his head. */
  private updateEmo(delta: number): void {
    if (!this.emo || !this.alive) {
      this.emoTimer = 0;
      return;
    }
    this.emoTimer += delta;
    if (this.emoTimer < EMO_FX.everyMs) return;
    this.emoTimer = 0;
    this.dropHeart();
  }

  /** Big Varu: grows / shrinks toward `sizeMultiplier`. The body, legs and belt follow `scaleX`; the hurtbox (physics circle and `hitRadius`) and the shadow are resized with it. */
  private easeSize(delta: number): void {
    if (this.sizeNow === this.sizeMultiplier) return;
    const gap = this.sizeMultiplier - this.sizeNow;
    this.sizeNow = Math.abs(gap) < 0.005 ? this.sizeMultiplier : this.sizeNow + gap * Math.min(1, (PLAYER.sizeEasePerSec * delta) / 1000);
    this.setScale(this.baseScale * this.sizeNow);
    setCircleHitbox(this, PLAYER.hitRadius * this.sizeNow);
    this.hitRadius = PLAYER.hitRadius * this.sizeNow;
    this.setShadowScale(this.sizeNow);
  }

  /** While the rusty belt lasts, rust flakes come off the strap (faster while he walks). */
  private updateRust(delta: number): void {
    const cfg = RUST_FX;
    if (!cfg.enabled || !this.rustyFlakes || !this.alive || !this.beltInHand) {
      this.rustTimer = 0;
      return;
    }
    const moving = this.body ? (this.body as Phaser.Physics.Arcade.Body).speed > 5 : false;
    this.rustTimer += delta;
    const every = moving ? cfg.everyMs : cfg.idleEveryMs;
    if (this.rustTimer < every) return;
    this.rustTimer -= every;
    for (let i = 0; i < cfg.perDrop; i++) this.dropRust();
  }

  /** A point on the held belt's strap, from its texture coordinates (128x128, centered), in the world. */
  private strapPoint(tx: number, ty: number, out: Phaser.Math.Vector2): Phaser.Math.Vector2 {
    const k = this.scaleX;
    const a = this.rotation + this.beltTilt; // the held belt sprite turns with its own tilt
    const lx = (tx - 64) * k;
    const ly = (ty - 64) * k;
    const c = Math.cos(a);
    const s = Math.sin(a);
    return out.set(this.x + lx * c - ly * s, this.y + lx * s + ly * c);
  }

  /** One flake: comes off a random point on the strap, then the emitter (`PlayerDrops`) pops it in, drops it, spins and fades it. */
  private dropRust(): void {
    const cfg = RUST_FX;
    const path = cfg.strapPath;
    const seg = Phaser.Math.Between(0, path.length - 2);
    const t = Math.random();
    const [ax, ay] = path[seg]!;
    const [bx, by] = path[seg + 1]!;
    const at = this.strapPoint(ax + (bx - ax) * t, ay + (by - ay) * t, this.scratchPoint);
    this.drops.rust(at.x + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx), at.y + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx));
  }

  /** One broken heart over his head: the emitter (`PlayerDrops`) pops it up, floats it, sways it and fades it. */
  private dropHeart(): void {
    const cfg = EMO_FX;
    this.drops.heart(
      this.x + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx),
      this.y + cfg.offsetY * this.sizeNow + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx),
    );
  }

  /** One letter of the trail: appears at his feet, floats up, sways and fades. Tweens are scene-owned, so a restart cleans them up. */
  private dropZ(cfg: ZLook = ENERGY_TRAIL, offsetY = 0): void {
    const step = cfg.cycle[this.zCount % cfg.cycle.length]!;
    this.zCount++;
    const x = this.x + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx);
    const y = this.y + offsetY + Phaser.Math.FloatBetween(-cfg.jitterPx, cfg.jitterPx);
    const letter = this.scene.add
      .text(x, y, step.letter, {
        fontFamily: FONT,
        fontSize: `${step.sizePx}px`,
        color: css(cfg.color),
        stroke: css(cfg.outline),
        strokeThickness: step.strokePx,
      })
      .setOrigin(0.5)
      .setDepth(cfg.depth)
      .setAlpha(cfg.alpha)
      .setAngle(Phaser.Math.FloatBetween(cfg.tiltDeg.min, cfg.tiltDeg.max))
      .setScale(0.4);
    const life = Phaser.Math.Between(cfg.lifeMs.min, cfg.lifeMs.max);
    const sway = (Math.random() < 0.5 ? -1 : 1) * cfg.swayPx;
    this.scene.tweens.add({ targets: letter, scale: 1, duration: life * 0.2, ease: 'Back.easeOut' });
    this.scene.tweens.add({ targets: letter, x: x + sway, duration: life, ease: 'Sine.easeInOut' });
    this.scene.tweens.add({
      targets: letter,
      y: y - Phaser.Math.Between(cfg.riseY.min, cfg.riseY.max),
      alpha: 0,
      duration: life,
      ease: 'Sine.easeIn',
      onComplete: () => letter.destroy(),
    });
  }

  /** The belt in his fist: gold and dripping goo while the golden belt is active. */
  private updateHeldBelt(delta: number): void {
    const gold = GOLD_BELT.enabled && this.goldenBelt;
    if (gold !== this.beltIsGold) {
      this.beltIsGold = gold;
      this.heldBelt.setTexture(...texArgs(gold ? Tex.VaruBeltGold : Tex.VaruBelt));
    }
    if (!gold || !this.beltInHand || !this.alive) return;
    this.gooTimer += delta;
    if (this.gooTimer < GOLD_BELT.held.everyMs) return;
    this.gooTimer -= GOLD_BELT.held.everyMs;
    const drip = this.bodyPoint(GOLD_BELT.held.dripOffset, this.tipPoint);
    this.goo.emitParticleAt(drip.x, drip.y, 1);
  }

  /** Legs follow the body every frame (also during the death spin), swinging forward/back in turn. */
  override preUpdate(time: number, delta: number): void {
    super.preUpdate(time, delta);
    delta = gameClock.scaled(delta); // from here on `delta` is game time, so the slow-mo of the last cat slows Varu's animation too
    this.easeSize(delta);
    this.advanceBackflip(delta);
    // Hide / show the body first: the legs and the cigarette ember follow `this.visible` below. A back flip hides it too (a stand-in plays it).
    const hidden = this.hiddenInTornado || this.flipMs >= 0;
    if (this.visible === hidden) this.setVisible(!hidden);
    this.updateSmokeBreak(delta);
    this.updateIdleHabits(delta);
    this.updateHeldBelt(delta);
    this.updateMilkTrail(delta);
    this.updateEnergyTrail(delta);
    this.updateEmo(delta);
    this.updateRust(delta);
    this.puffSmoke(delta);
    const r = this.rotation;
    const k = this.scaleX;
    const fx = Math.sin(r);
    const fy = -Math.cos(r); // local "up" in world space
    const swing = this.legSwing * k;
    this.legL.setPosition(this.x + fx * swing, this.y + fy * swing).setRotation(r).setScale(k).setAlpha(this.alpha).setVisible(this.visible);
    this.legR.setPosition(this.x - fx * swing, this.y - fy * swing).setRotation(r).setScale(k).setAlpha(this.alpha).setVisible(this.visible);
    this.heldBelt
      .setPosition(this.x, this.y).setRotation(r + this.beltTilt).setScale(k).setAlpha(this.alpha)
      .setVisible(this.visible && this.beltInHand);
    if (this.flipPose.on) this.applyBackflip();
  }

  override flash(color = 0xffffff, ms = 80): void {
    super.flash(color, ms);
    for (const leg of [this.legL, this.legR, this.heldBelt]) leg.setTint(color).setTintMode(Phaser.TintModes.FILL);
    this.scene.time.delayedCall(ms, () => {
      for (const leg of [this.legL, this.legR, this.heldBelt]) {
        if (!leg.active) continue;
        leg.clearTint();
        leg.setTintMode(Phaser.TintModes.MULTIPLY);
      }
    });
  }

  override destroy(fromScene?: boolean): void {
    this.legL.destroy();
    this.legR.destroy();
    this.heldBelt.destroy();
    this.flipBody.destroy();
    this.smoke.destroy();
    this.ember.destroy();
    this.goo.destroy();
    this.drops.destroy();
    this.gooBurst.destroy();
    this.milkLine.destroy();
    super.destroy(fromScene);
  }

  /** Returns true if the hit landed (false during i-frames). `source` says what hurt him (a cat type, a projectile kind...) for the bad luck system. */
  takeDamage(amount: number, fromX: number, fromY: number, source?: string): boolean {
    const now = gameClock.now;
    if (this.rolling) {
      if (this.alive && now - this.lastSaveAt >= DODGE.saveWordEveryMs) {
        this.lastSaveAt = now;
        bus.emit(Events.DodgeSave, { x: this.x, y: this.y });
      }
      return false;
    }
    if (!this.alive || this.godMode || now < this.invincibleUntil) return false;

    amount *= getDifficulty().damageTaken; // Ușor / Greu / Coșmar: every hit on him is scaled here, one place for cats, shots, bombs and bosses
    this.hp = Math.max(0, this.hp - amount);
    this.invincibleUntil = now + PLAYER.invincibleMs * getDifficulty().invincible;
    this.applyKnockback(fromX, fromY, PLAYER.hurtKnockback);
    this.flash(0xff4444, 100);
    this.scene.tweens.add({ targets: this, alpha: 0.35, duration: 70, yoyo: true, repeat: 4, onComplete: () => this.setAlpha(1) });

    const hurt: PlayerHurtPayload = { x: this.x, y: this.y, source, amount };
    bus.emit(Events.PlayerHurt, hurt);
    this.emitHealth();
    if (!this.alive) {
      this.setVelocity(0, 0);
      bus.emit(Events.PlayerDied);
    }
    return true;
  }

  heal(amount: number): void {
    if (!this.alive) return;
    this.hp = Math.min(this.maxHp, this.hp + amount);
    this.emitHealth();
  }

  /** Dev only (debug card): sets health to this share of the maximum (at least 1 HP, so it never kills). */
  debugSetHealth(share: number): void {
    if (!this.alive) return;
    this.hp = Math.min(this.maxHp, Math.max(1, Math.round(this.maxHp * share)));
    this.emitHealth();
  }

  private emitHealth(): void {
    const payload: PlayerHealthPayload = { hp: this.hp, maxHp: this.maxHp };
    bus.emit(Events.PlayerHealth, payload);
  }
}
