/** @file The jokes (Romanian), grouped by trigger, plus boss intro lines and photo captions. */
import type { BossType } from '../config/balance';
import type { JokeCategory } from '../config/jokes';
import type { PhotoId } from '../assets/keys';

/**
 * THE JOKES. Romanian, grouped by the situation that triggers them (timing lives in config/jokes.ts).
 * One random line of the right group is shown. `{n}` is replaced by the streak length.
 * The old lines in content/lines.ts (hit words, Varu's lines...) still work next to these.
 *
 * >>> PLACEHOLDERS: the lines marked "PLACEHOLDER" are generic. Replace them with the real
 * >>> nicknames and inside jokes. Nothing else in the code needs to change.
 */
export const JOKE_LINES: Record<JokeCategory, readonly string[]> = {
  lowHp: [
    'Varule, ai grijă!',
    'Doar o zgârietură... zgârietură mare.',
    'Unde-i Kent 8 clasic?',
    'Carpati,te rog frumos!',
    'Nu acum, vă rog!',
  ],
  killStreak: [
    '{n} la rând! Pisicile plâng.',
    '{n} pisici! Varu nu se oprește!',
    'Seria de {n}! Cureaua e pe foc!',
    '{n}! Cineva sa cheme veterinarul!',
  ],
  waveStart: [
    'Se aud mieunaturi...',
    'Încă o rundă de dictare.',
    'Pisicile au adus chitaristi.',
    'Respiră adânc, Varule.',
    'Varule,sa n-o inghiti!',
    'Pisicile din campus,vin cu o sticla de vin'
  ],
  waveCleared: [
    'Liniște. Suspect de liniște.',
    'Pisicile au plecat.',
    'Varu isi trage respiratia.',
    'Prea usor pentru varu',
    'Varu a scapat de pisici',
    'Hehehaw'
  ],
  // Used when a boss has no line of its own in BOSS_INTRO_LINES below.
  bossIntro: ['Un mata sălbatica apare!', 'Asta nu mai e o pisică obișnuită...'],
  bossPhase2: ['Acum s-a supărat pe bune!', 'Mănușile au căzut. Ghearele au ieșit.'],
  pickup: [
    'Mmm, bun!',
    'Exact ce îmi trebuia.',
    'Mulțumesc, CNE Cernavoda!',
    'Cineva a lăsat asta pentru Varu.',
    'E numele meu pe ea',
    'OO DAAA',
    'asta sigur ma va ajuta'
  ],
  nearDeath: ['Încă respir,ms carpati!', 'Nu mă lăsa, cureauo!', 'Cu un fir de păr!','LUPTA CONTRA FOAMEI ESTE PREA MARE','Foamea aproape ma doboara','#REZIST','Zdrentelor lasati-ma','Acceptati si POS?'],
  gameOver: ['Pisicile ti-au dat la muie.', 'Revanșa e gratis.'],
};

/** PLACEHOLDER: boss intro lines, one list per boss. Put the real nicknames here. */
export const BOSS_INTRO_LINES: Record<BossType, readonly string[]> = {
  queen: ['PLACEHOLDER: ea își cere tronul înapoi.', 'Regina vrea o plecăciune. Sau o curea noua.'],
  mafia: ['PLACEHOLDER: cine i-a frânt inima?', 'Pisica Emo: \"Sunt bine. (Nu sunt.)\"'],
  federer: ['PLACEHOLDER: serviciu, retur, apoi smash.', 'Pisica Federer: 20 de turnee, 0 mile de milă.'],
};

/**
 * PLACEHOLDER captions under the friend photos. Write the friend's real name or nickname.
 * The photos themselves go in public/assets/photos/ and in assets/manifest.ts (PHOTO_MANIFEST).
 */
export const PHOTO_CAPTIONS: Record<PhotoId, string> = {
  queen: 'PLACEHOLDER: numele prietenei (Ioana)',
  mafia: 'PLACEHOLDER: numele prietenului (AnatasYOU)',
  federer: 'PLACEHOLDER: numele prietenului (Simona Miaulep)',
  gameOver: 'PLACEHOLDER: cine râde de Varu',
  ending: 'PLACEHOLDER: toată gașca',
};

/** Fill in `{n}`-style gaps. Unknown gaps stay as they are. */
export function fillLine(line: string, vars: Readonly<Record<string, string | number>>): string {
  return line.replace(/\{(\w+)\}/g, (whole, name: string) => (name in vars ? String(vars[name]) : whole));
}
